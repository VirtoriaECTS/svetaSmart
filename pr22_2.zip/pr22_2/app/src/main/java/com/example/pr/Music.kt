package com.example.pr

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import okhttp3.OkHttpClient
import org.json.JSONException
import org.json.JSONObject



class Music : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)
    }
    private fun searchArtistId(artistName: String) :String{
        var returnText: String = ""
        val apiKey = "EgwwsimTTHMbpAHpSUFoWVNXYiBCMihNUQckZeaQ"
        val searchUrl = "https://api.discogs.com/database/search?q=$artistName&type=artist&token=$apiKey"

        val queue = Volley.newRequestQueue(this)

        val stringRequest = StringRequest(
            com.android.volley.Request.Method.GET, searchUrl,
            { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val resultsArray = jsonObject.getJSONArray("results")

                    if (resultsArray.length() > 0) {
                        val artistInfo = resultsArray.getJSONObject(0) // Первый результат
                        val artistId = artistInfo.optInt("id")
                        returnText = artistId.toString()

                        // Теперь у вас есть id артиста
                        Log.d("MyLog", "ID артиста $artistName: $artistId")

                    } else {
                        Log.d("MyLog", "Информация о $artistName не найдена.")
                    }

                }
                catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            {
                Log.d("MyLog", "Volley error: ${it.message}")
            })

        queue.add(stringRequest)
        return returnText
    }




    private fun getResualt( idAtrist: String) {

        val textInfoSet: TextView = findViewById(R.id.textView)
        val find = findViewById<EditText>(R.id.info_text)
        val artistName = find.text.toString()

        val url = "https://api.discogs.com/artists/$idAtrist?callback=$artistName"

        val queue = Volley.newRequestQueue(this)

        val stringRequest = StringRequest(
            com.android.volley.Request.Method.GET, url,
            { response ->
                // Обрабатываем JSONP-ответ
                val jsonpData = response.substring(response.indexOf("(") + 1, response.lastIndexOf(")"))
                try {
                    val jsonObject = JSONObject(jsonpData)
                    val artistData = jsonObject.getJSONObject("data")

                    val name = artistData.getString("name")
                    val realname = artistData.getString("realname")
                    val profile = artistData.getString("profile")
                    val namevariations = artistData.getJSONArray("namevariations").join("\n")

                    val artistInfo = "Имя артиста: $name\nНастоящее имя: $realname\nПрофиль: $profile\nВарианты имени:\n$namevariations"
                    textInfoSet.text = artistInfo
                } catch (e: JSONException) {
                    e.printStackTrace()
                }

                Log.d("MyLog", "Volley: $response")
            },
            {
                Log.d("MyLog", "Volley error: ${it.message}")
            })

        queue.add(stringRequest)
    }


    fun getResualtBut(view: View) {
        //getResualt()
        val find = findViewById<EditText>(R.id.info_text)
        val idArtist:String = searchArtistId(find.text.toString())
        val textInfoSet: TextView = findViewById(R.id.textView)
        textInfoSet.text = "Вывод ${find.text}"
        //getResualt(idArtist)
        /*if(idArtist.length == 0){
            //если такой певец не нашелся, допиши тестовую ситуацию
        }
        else{
            getResualt(idArtist)
        }*/

    }

}
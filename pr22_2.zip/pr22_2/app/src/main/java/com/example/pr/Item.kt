package com.example.pr

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity (tableName = "items")

//коллоны
data class Item(

    //ид
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null,

    //Исполнитель
    @ColumnInfo(name = "avtor")
    var avtor: String,

    //название
    @ColumnInfo(name="name_music")
    var name_music:String,

    //цена
    @ColumnInfo(name="price")
    var price:Int,


)